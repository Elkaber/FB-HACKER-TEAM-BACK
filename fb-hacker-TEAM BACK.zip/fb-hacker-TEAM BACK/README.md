`apt update && apt upgrade`

`pkg install python python2 git`

`'git clone '`

`cd fb-hacker`

`python2 fb.py`
جميع الحقوق محفوظه لدي قناة @TEAMBACK
